package kg.geechtech.game.general;

import kg.geechtech.game.general.players.Magic;
import kg.geechtech.game.general.players.SuperAbility;
import kg.geechtech.game.general.players.Warrior;

public class Main {
    public static void main(String[] args){

        RPG_Game.startGame();
    }
}