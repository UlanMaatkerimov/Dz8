package kg.geechtech.game.general.players;

public interface HavingSuperAbility {
    void applySuperPower(Boss boss, Hero[] hero);
}
