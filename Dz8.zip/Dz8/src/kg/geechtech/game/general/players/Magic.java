package kg.geechtech.game.general.players;

public class Magic extends Hero{


    public Magic(int health, int damage) {
        super(health, damage, SuperAbility.MAGIC_POWER);
    }

    @Override
    public void applySuperPower(Boss boss, Hero[] hero) {

    }
}
