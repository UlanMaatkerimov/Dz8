package kg.geechtech.game.general.players;

public enum SuperAbility {
    HEAL, CRITICAL_DAMAGE, MAGIC_POWER, SAVE_DAMAGE_AND_REVERT
}
