package kg.geechtech.game.general.players;

public class Berserk extends Hero {


    public Berserk(int health, int damage) {
        super(health, damage, SuperAbility.SAVE_DAMAGE_AND_REVERT);
    }

    @Override
    public void applySuperPower(Boss boss, Hero[] hero) {
        for (int i = 0; i < hero.length; i++) {
            if (boss.getHealth() > 0) {
                this.setHealth(hero[i].getHealth() - (boss.getDamage() - 5));
                this.setDamage(hero[i].getDamage() + 5);
            }
            System.out.println("Berserker used abilities");
        }


    }
}
